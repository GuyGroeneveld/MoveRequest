﻿
<###############Disclaimer#####################################################

The sample scripts are not supported under any Microsoft standard support 
program or service. The sample scripts are provided AS IS without warranty  
of any kind. Microsoft further disclaims all implied warranties including,  
without limitation, any implied warranties of merchantability or of fitness for 
a particular purpose. The entire risk arising out of the use or performance of  
the sample scripts and documentation remains with you. In no event shall 
Microsoft, its authors, or anyone else involved in the creation, production, or 
delivery of the scripts be liable for any damages whatsoever (including, 
without limitation, damages for loss of business profits, business interruption, 
loss of business information, or other pecuniary loss) arising out of the use 
of or inability to use the sample scripts or documentation, even if Microsoft 
has been advised of the possibility of such damages.

###############Disclaimer#####################################################>




<#Function to retrieve bytes value from text value like "4.64 MB (4,865,683 bytes)"#>
Function Get-BytesFromExString
{
    [CmdletBinding()]
    
    Param(
         [parameter(ValueFromPipeline=$True)]
         [string]$ByteString = ""   
        )
    [double]$bytes = 0
    if($ByteString.length -gt 10 )
    {
        $leftbracket = $ByteString.IndexOf("(") +1
        $rightbracket = $ByteString.IndexOf(")") -6 
        $stringlength = $rightbracket - $leftbracket 
        $Bytes = $ByteString.Substring($leftbracket,$stringlength)
        $Bytes = $Bytes -replace "[^0-9]"
    }
    else
    {
        Write-Verbose -Message "Could not convert string $ByteString"
    }

    return $Bytes
}

<#Function to create log entry in file $LogName#>
Function Write-LogEntry 
{
    param(
        [string] $LogName=$Null ,
        [string] $LogEntryText
         )

    [string]$currentdaytime = get-date -Format G
    [string]$logstring = "$currentdaytime : $LogEntryText"


    if ($LogName -NotLike $Null) 
    {
        
        $logstring | Out-File -FilePath $LogName -append
        Write-Verbose -Message $logstring
    }
    Else
    {
        Write-Verbose -Message $logstring
    }
}



<#We may have report gathered through get-moverequeststatistics or get-migrationuser. The properties don't match
So we need to adapt and make sure the result is consistent#>
Function Get-MoveRequestProperties 
{
    [cmdletbinding()]
    Param (
        [parameter(ValueFromPipeline=$True)]
        $MoveRequest
        )
    [hashtable]$Return = @{} 
    
    if ($MoveRequest.MailboxIdentity.Name)
        {
            # we have a move request mbx
            $return.mailbox = $MoveRequest.MailboxIdentity.Name
            $return.batch = $MoveRequest.batchname.replace("MigrationService:","")
            $return.TotalMailboxSize = $MoveRequest.TotalMailboxSize.tostring()
        }
        
        Elseif ($MoveRequest.MailboxIdentifier)
        {
            # we have a migration user mbx
            $return.Mailbox = $MoveRequest.MailboxIdentifier
            $return.batch = $MoveRequest.BatchId.name
            $return.TotalMailboxSize = $MoveRequest.EstimatedTotalTransferSize.ToString()
        }

        Else
        {
            #We don't have a valid mbx export
            Write-Output -InputObject "$MoveRequest Does not contain move request or migration user infos"
        }
    
    Return $Return 
}


Function Get-MoveRequestFailures
{
 <#
  .SYNOPSIS
  The function Get-MoveRequestFailures allows to retrieve all the failure events that occurred for a mailbox move request.
  The source must be a live result form a "Get-MoveRequestStatistics -Includereport" or from an export XML. 
  Note that the Get-MoveRequestStatistics command may take time. If you have several move request to analyse, it is better to
  use the function Get-MoveRequestReport or Get-MoveRequestReportsFromBatch and then use the XMLs

  .DESCRIPTION
  Get-MoveRequestFailures search the move request report for all failures that did occurs for the move request
  This allows you to see the full failure history and take the correction action if needed.
  By default we exclude the permission mapping errors as they may flood your results, you can expressly request them if needed
  with specify the parameter PermissionMappingError

  In case of Permission mapping, we retrieve the SID and mailbox folder involved.

  Author: Guy Groeneveld guyg@microsoft.com

  .EXAMPLE
  To get all the failures for a single move request
  
  Get-MoveRequestStatistics user1@contoso.com -IncludeReport | Get-MoveRequestFailures
  
  .EXAMPLE
  To get all the failure for for all move requests based on XMLs and export it to a CSV
  
  Dir *.xml | Foreach { Import-CliXML $_ | Get-MoveRequestFailures } | Export-CSV -path .\failures.csv -NoTypeInformation -Encoding UTF8

  .EXAMPLE
  Let suppose you have a move that did reach the Synced state some time ago, you decide to complete the move and get some failure
  In that case, you don't want to have all the failures that occurred since the first sync was started but rather thos you just got.
  To retrieve the failures that occurred in the last 15 minutes you can do:

  Get-MoveRequestStatistics user1@contoso.com -IncludeReport | Get-MoveRequestFailures -DateStart (Get-Date).AddMinutes(-15)

  .EXAMPLE
  You want to get the permission mapping errors

  Get-MoveRequestStatistics user1@contoso.com -IncludeReport | Get-MoveRequestFailures -PermissionMappingError
  
  .PARAMETER MoveRequest
  The source move request including report.

  .PARAMETER DateStart
  The start date in local time for retrieving move request failures

  .PARAMETER DateEnd
  The end date in local time for retrieving move request failures

  .PARAMETER PermissionMappingError
  Setting this parameter allows to retrieve the permission mapping errors including unknown SID and mailbox folder

  .PARAMETER LogName
  The name of a text file to write the mailbox name being scanned. This will appear also with the Verbose mode
  #>

 
    [cmdletbinding()]
    Param (
        [parameter(ValueFromPipeline=$True,Mandatory=$true,Position=0)]
        $MoveRequest,
        [datetime]$DateStart = 0,
        [datetime]$DateEnd = (Get-Date),
        [switch]$PermissionMappingError,
        [string]$LogName=$null
        )
    Process
    {    
        
        #We use local time everywhere, so making sure the time is seen as such
        $DateStart = [datetime]::SpecifyKind("$DateStart", "local")
        $DateEnd = [datetime]::SpecifyKind("$DateEnd", "local")
        
        $FailureList = [System.Collections.ArrayList]@()

        $mailbox = (Get-MoveRequestProperties $MoveRequest).mailbox

        Write-LogEntry -LogEntryText "Retrieving move request failures for move request of mailbox $mailbox" -LogName $LogName
  
        for ($fail = 0; $fail -lt $MoveRequest.Report.Failures.count ; $fail++)
        {
        if ($MoveRequest.report.failures.count -gt 0 -and ($MoveRequest.Report.Failures[$fail].Timestamp).ToLocalTime() -ge $DateStart -and ($MoveRequest.Report.Failures[$fail].Timestamp).ToLocalTime() -le $DateEnd)
            {
                if ($MoveRequest.Report.Failures[$fail].Failuretype -like "*PrincipalMappingException" -and $PermissionMappingError -eq $True)
                {
                    $datacontext = $MoveRequest.Report.Failures[$fail].datacontext -split "\r?\n"
                    [string]$SID = $datacontext[0].replace(";","")
                    $indexendfoldername = ($datacontext[3].indexof("'",10)) + 1
                    [string]$folder = $datacontext[3].substring(0,$indexendfoldername)

                    [string]$FailureMessage = ($MoveRequest.Report.Failures[$fail].Message.replace("`n","")) + ", " + $SID + ", " + $folder

                    $failure = New-Object -type PSObject
                    $failure | Add-Member -MemberType NoteProperty -Name "Mailbox" -Value $mailbox
                    $failure | Add-Member -MemberType NoteProperty -Name "TimeStamp" -Value ($MoveRequest.Report.Failures[$fail].Timestamp).ToLocalTime()
                    $failure | Add-Member -MemberType NoteProperty -Name "FailureType" -Value $MoveRequest.Report.Failures[$fail].Failuretype
                    $failure | Add-Member -MemberType NoteProperty -Name "FailureMessage" -Value $FailureMessage

                }
                Elseif ($MoveRequest.Report.Failures[$fail].Failuretype -Notlike "*PrincipalMappingException")
                {
                    $failure = New-Object -type PSObject
                    $failure | Add-Member -MemberType NoteProperty -Name "Mailbox" -Value $mailbox
                    $failure | Add-Member -MemberType NoteProperty -Name "TimeStamp" -Value ($MoveRequest.Report.Failures[$fail].Timestamp).ToLocalTime()
                    $failure | Add-Member -MemberType NoteProperty -Name "FailureType" -Value $MoveRequest.Report.Failures[$fail].Failuretype
                    $failure | Add-Member -MemberType NoteProperty -Name "FailureMessage" -Value ($MoveRequest.Report.Failures[$fail].Message.replace("`n",""))
                }
                [void]$FailureList.Add($failure)
            }
        
        }

        $entryfailurelist = 0..($MoveRequest.Report.Entries.failure.count) | ForEach-Object { $MoveRequest.Report.Entries[$_].failure } 
        
        $entryfailurelist = $entryfailurelist | Where-Object { $_.timestamp  }
        
        if ($entryfailurelist)
        {

            for ($entryfail = 0 ; $entryfail -lt $entryfailurelist.count ; $entryfail++)
            {
           
                if ($entryfailurelist[$entryfail].Failuretype -like "*PrincipalMappingException" )
                {
                    #We don't want to add the mapping failures here as they appear in both locations and thus just skip them
                    
                }
                Else
                {

                    $failure = New-Object -type PSObject
                    $failure | Add-Member -MemberType NoteProperty -Name "Mailbox" -Value $mailbox
                    $failure | Add-Member -MemberType NoteProperty -Name "TimeStamp" -Value $entryfailurelist[$entryfail].Timestamp
                    $failure | Add-Member -MemberType NoteProperty -Name "FailureType" -Value $entryfailurelist[$entryfail].Failuretype
                    $failure | Add-Member -MemberType NoteProperty -Name "FailureMessage" -Value ($entryfailurelist[$entryfail].Message.replace("`n",""))
               
                    [void]$FailureList.Add($failure)
                }
            

            }
        }
    
    return $FailureList
    }
}


Function Get-MoveRequestConnections
{
   <#
  .SYNOPSIS
  The function Get-MoveRequestConnections allows to retrieve all the connection events that occurred for a mailbox move request.
  The source must be a live result form a "Get-MoveRequestStatistics -Includereport" or from an exported XML of it. 
  Note that the Get-MoveRequestStatistics command may take time. If you have several move request to analyse, it is better to
  use the function Get-MoveRequestReport or Get-MoveRequestReportsFromBatch and then use the XMLs

  .DESCRIPTION
  Get-MoveRequestConnections search the move request report for all connections that did occurs for the move request
  This allows you to see the full connection history, the MRS, MRS Proxy and Mailbox servers in use. The HLB parameter allows to retrieve the 
  repartition of requests among the MRSProxy servers. This can help in determining if the load balancer is performing correctly. Proxyonly
  will get only the connection to on premises. Bear in mind that for Exchange 2013 and 2016, the CAS contacted will proxy the request. 
  If the destination mailbox is 2013 or 2016 we end up to use the MRSProxy on the Mailbox server of the moving mailbox.
  If the mailbox is 2007 or 2010 we end up on a 2013/2016 Mailbox role which connect then to the remote mailbox server
  
  Author: Guy Groeneveld guyg@microsoft.com

  .EXAMPLE
  To get all the connections for a single move request
  
  Get-MoveRequestStatistics user1@contoso.com -IncludeReport | Get-MoveRequestConnections
  
  .EXAMPLE
  To get all the connections for for all move requests based on XMLs and export it to a CSV
  
  Dir *.xml | Foreach { Import-CliXML $_ | Get-MoveRequestConnections } | Export-CSV -path .\Connections.csv -NoTypeInformation -Encoding UTF8

  .EXAMPLE
  Let suppose you want to get all the connection attempts made during the last 15 minutes

  Get-MoveRequestStatistics user1@contoso.com -IncludeReport | Get-MoveRequestConnections -DateStart (Get-Date).AddMinutes(-15)

  .EXAMPLE
  You want to get only the MRSProxy connection to focus on network connectivity

  Get-MoveRequestStatistics user1@contoso.com -IncludeReport | Get-MoveRequestFailures -proxyonly
  
  .PARAMETER MoveRequest
  The source move request including report.

  .PARAMETER DateStart
  The start date in local time for retrieving move request connection

  .PARAMETER DateEnd
  The end date in local time for retrieving move request connection

  .PARAMETER ProxyOnly
  This will retrieve only the MRSProxy connections, so the connection from Exchange Online to your On Premises environment

  .PARAMETER LogName
  The name of a text file to write the mailbox name being scanned. This will appear also with the Verbose mode
  #>

    [cmdletbinding()]
    Param (
        [parameter(ValueFromPipeline=$True,Mandatory=$true,Position=0)]
        $MoveRequest,
        [datetime]$DateStart = 0,
        [datetime]$DateEnd = (Get-Date),
        [switch]$ProxyOnly,
        [switch]$HLB,
        [string]$LogName=$null
        )
    Process
    {

    #We use local time everywhere, so making sure the time is seen as such
    $DateStart = [datetime]::SpecifyKind("$DateStart", "local")
    $DateEnd = [datetime]::SpecifyKind("$DateEnd", "local")

    $Connectivityitem = [System.Collections.ArrayList]@()
    $mailbox = (Get-MoveRequestProperties $MoveRequest).mailbox
    [string]$previousmailbox = ""
    [string]$previousproxy = ""
    [int]$ProxyCount = 0

    Write-LogEntry -LogEntryText "Retrieving move request connections for mailbox $mailbox" -LogName $LogName

    for ($j=0 ; $j -lt $MoveRequest.Report.connectivity.count ; $j++)
        {
                
        if (($MoveRequest.Report.connectivity[$j].Timestamp).ToLocalTime() -ge $DateStart -and ($MoveRequest.Report.connectivity[$j].Timestamp).ToLocalTime() -le $DateEnd)
      
            { 
                if ($HLB)
                {
                    $ProxyOnly = $True
                }

                If ($ProxyOnly -and ($MoveRequest.report.connectivity[$j].proxyname.Length -eq 0))

                {
                    #We are only looking for proxy requests, so we skip others
                }
                Else
                {
                    if ($HLB)
                    {
                        #We add an entry only if we hadn't seen it before in order to determine if the load balancing is performing well
                        if ( $previousmailbox -eq $mailbox -and $previousproxy -eq $MoveRequest.Report.Connectivity[$j].proxyname)
                        {
                            #We do nothing
                        }
                        Else
                        {
                            
                            $ProxyCount++
                            $list = New-Object -type PSObject
                            $List | Add-Member -MemberType NoteProperty -Name "Mailbox" -Value $mailbox
                            $List | Add-Member -MemberType NoteProperty -Name "ServerKind" -Value $MoveRequest.Report.Connectivity[$j].serverkind
                            $List | Add-Member -MemberType NoteProperty -Name "Proxy" -Value $MoveRequest.Report.Connectivity[$j].proxyname
                            $List | Add-Member -MemberType NoteProperty -Name "ServerName" -Value $MoveRequest.report.connectivity[$j].Servername
                            $List | Add-Member -MemberType NoteProperty -Name "ProxyVersionStr" -Value $MoveRequest.report.connectivity[$j].ProxyVersionStr
                            $List | Add-Member -MemberType NoteProperty -Name "ServerVersionStr" -Value $MoveRequest.report.connectivity[$j].ServerVersionStr
                            $List | Add-Member -MemberType NoteProperty -Name "ProxyCount" -Value $ProxyCount
            
                            [void]$Connectivityitem.Add($List)

                            if ($MoveRequest.Report.Connectivity[$j].proxyname)
                            {
                                $previousmailbox = $mailbox
                                $previousproxy = $MoveRequest.Report.Connectivity[$j].proxyname 
                                                                
                            }
                        }
                    }
                    Else
                    {
                        $list = New-Object -type PSObject
                        $List | Add-Member -MemberType NoteProperty -Name "Mailbox" -Value $mailbox
                        $List | Add-Member -MemberType NoteProperty -Name "TimeStamp" -Value ($MoveRequest.Report.Connectivity[$j].Timestamp).ToLocalTime()
                        $List | Add-Member -MemberType NoteProperty -Name "ServerKind" -Value $MoveRequest.Report.Connectivity[$j].serverkind
                        $List | Add-Member -MemberType NoteProperty -Name "Proxy" -Value $MoveRequest.Report.Connectivity[$j].proxyname
                        $List | Add-Member -MemberType NoteProperty -Name "ServerName" -Value $MoveRequest.report.connectivity[$j].Servername
                        $List | Add-Member -MemberType NoteProperty -Name "ProxyVersionStr" -Value $MoveRequest.report.connectivity[$j].ProxyVersionStr
                        $List | Add-Member -MemberType NoteProperty -Name "ServerVersionStr" -Value $MoveRequest.report.connectivity[$j].ServerVersionStr

                        $list.psobject.Typenames.Insert(0,'MoveRequestConnections')
            
                        [void]$Connectivityitem.Add($List)
                        $previousmailbox = $mailbox
                        $previousproxy = $MoveRequest.Report.Connectivity[$j].proxyname 
                    }
                    
                }
              
            }
        } 
    return $Connectivityitem
    } 
    
}



Function Get-MoveRequestThrottlingEvents
{
 <#
  .SYNOPSIS
  The function Get-MoveRequestThrottlingEvents allows to retrieve all the stalled events that occurred for a mailbox move request.
  The source must be a live result form a "Get-MoveRequestStatistics -Includereport" or from an exported XML of it. 
  Note that the Get-MoveRequestStatistics command may take time. If you have several move request to analyse, it is better to
  use the function Get-MoveRequestReport or Get-MoveRequestReportsFromBatch and then use the XMLs

  .DESCRIPTION
  Get-MoveRequestThrottlingEvents search the move request report for all stalled events that did occurs for the move request
  This allows you to determine when the move request got stalled and why. This can be useful when you want to determine why a mailbox move took longer than expected.
  The stalled entries will reflect by their name what throttled them. If a mailbox move request is constantly throttled and taking too much time to be moved
  The easiest solution is to recreate the move request.
  
  Author: Guy Groeneveld guyg@microsoft.com

  .EXAMPLE
  To get all the connections for a single move request
  
  Get-MoveRequestStatistics user1@contoso.com -IncludeReport | Get-MoveRequestThrottlingEvents
  
  .EXAMPLE
  To get all the stalled events for for all move requests based on XMLs and export it to a CSV
  
  Dir *.xml | Foreach { Import-CliXML $_ | Get-MoveRequestThrottlingEvents } | Export-CSV -path .\stalled.csv -NoTypeInformation -Encoding UTF8

  .EXAMPLE
  Let suppose you want to get all the stalled events made during the last 15 minutes

  Get-MoveRequestStatistics user1@contoso.com -IncludeReport | Get-MoveRequestThrottlingEvents -DateStart (Get-Date).AddMinutes(-15)

  .PARAMETER MoveRequest
  The source move request including report.

  .PARAMETER DateStart
  The start date in local time for retrieving move request stall events

  .PARAMETER DateEnd
  The end date in local time for retrieving move request stall events

  .PARAMETER LogName
  The name of a text file to write the mailbox name being scanned. This will appear also with the Verbose mode
  #> 
  
    [cmdletbinding()]
    Param (
        [parameter(ValueFromPipeline=$True)]
        $MoveRequest,
        [datetime]$DateStart = 0,
        [datetime]$DateEnd = (Get-Date),
        [string]$LogName=$null
        )
    Process
    { 

    #We use local time everywhere, so making sure the time is seen as such
    $DateStart = [datetime]::SpecifyKind("$DateStart", "local")
    $DateEnd = [datetime]::SpecifyKind("$DateEnd", "local")

    $StalledItems=[System.Collections.ArrayList]@()
    $mailbox = (Get-MoveRequestProperties $MoveRequest).mailbox

    Write-LogEntry -LogEntryText "Retrieving move request stalled for mailbox $mailbox" -LogName $LogName

        for ($j=0 ; $j -lt $MoveRequest.Report.Entries.message.count ; $j++)
        {

        if (($MoveRequest.Report.Entries[$j].CreationTime).ToLocalTime() -ge $DateStart -and ($MoveRequest.Report.Entries[$j].CreationTime).ToLocalTime() -le $DateEnd)
      
            { 
                #Retrieveing stalled messages
                if ($MoveRequest.Report.Entries[$j].message.tostring() -like "*unfavorable server health*")
                {
                    #Removing useless text as it is always the same
                    [string]$stalled = $MoveRequest.Report.Entries[$j].message.tostring()
                    
                    $splitted = $stalled.Split("'")

                    if ($splitted[3])
                    {
                        [datetime]$resume = $splitted[3]
                        $resume = [datetime]::SpecifyKind("$resume", "Utc")
                        $resume = $resume.ToLocalTime()
                    }
                    Else
                    {
                        $resume = "N/A"
                    }


                    $list = New-Object -type PSObject
                    $List | Add-Member -MemberType NoteProperty -Name "Mailbox" -Value $mailbox
                    $List | Add-Member -MemberType NoteProperty -Name "TimeStamp" -Value ($MoveRequest.Report.Entries[$j].CreationTime).ToLocalTime()
                    $list | Add-Member -MemberType NoteProperty -Name "ThrottlingState" -Value $splitted[1]
                    $list | Add-Member -MemberType NoteProperty -Name "ResumeAfter" -Value $resume
                    $list | Add-Member -MemberType NoteProperty -Name "Message" -Value $stalled

                    $list.psobject.Typenames.Insert(0,'MoveRequestThrottlingEvents')

                    [void]$StalledItems.Add($List)

                    $StalledItems
                }

            }

        }
    return $StalledItems
    }

}

Function Get-MoveRequestSourceLatency
{
<#
  .SYNOPSIS
  The function Get-MoveRequestSourceLatency allows to retrieve all the source latency that were measured for a mailbox move request.
  The source must be a live result form a "Get-MoveRequestStatistics -Includereport" or from an exported XML of it. 
  Note that the Get-MoveRequestStatistics command may take time. If you have several move request to analyse, it is better to
  use the function Get-MoveRequestReport or Get-MoveRequestReportsFromBatch and then use the XMLs

  .DESCRIPTION
  Get-MoveRequestSourceLatency search the move request report for source latency that did occurs for the move request
  This allows you to determine when the move request got stalled and why. This can be useful when you want to determine why a mailbox move took longer than expected.
  
  Bear in mind that what matter is the average, the recommendation being to have it as low as possible. You can have peaks and be perfectly fine.
  Having the latency history helps determining if there's been a network issue and then look for throttling events or failures at the corresponding time.
  
  Author: Guy Groeneveld guyg@microsoft.com

  .EXAMPLE
  To get all the connections for a single move request
  
  Get-MoveRequestStatistics user1@contoso.com -IncludeReport | Get-MoveRequestSourceLatency
  
  .EXAMPLE
  To get all the stalled events for for all move requests based on XMLs and export it to a CSV
  
  Dir *.xml | Foreach { Import-CliXML $_ | Get-MoveRequestSourceLatency } | Export-CSV -path .\stalled.csv -NoTypeInformation -Encoding UTF8

  .EXAMPLE
  Let suppose you want to get all the stalled events made during the last 15 minutes

  Get-MoveRequestStatistics user1@contoso.com -IncludeReport | Get-MoveRequestSourceLatency -DateStart (Get-Date).AddMinutes(-15)

  .EXAMPLE
  If you want to have the average latency

  Get-MoveRequestStatistics user1@contoso.com -IncludeReport | Get-MoveRequestSourceLatency | Measure-Object -Property Sourcelatency -Average -Sum

  .PARAMETER MoveRequest
  The source move request including report.

  .PARAMETER DateStart
  The start date in local time for retrieving move request latency events

  .PARAMETER DateEnd
  The end date in local time for retrieving move request latency events

  .PARAMETER LogName
  The name of a text file to write the mailbox name being scanned. This will appear also with the Verbose mode
  #> 

    [cmdletbinding()]
    Param (
        [parameter(ValueFromPipeline=$True)]
        $MoveRequest,
        [datetime]$DateStart = 0,
        [datetime]$DateEnd = (Get-Date),
        [string]$LogName=$null
        )
    Process
    { 

    #We use local time everywhere, so making sure the time is seen as such
    $DateStart = [datetime]::SpecifyKind("$DateStart", "local")
    $DateEnd = [datetime]::SpecifyKind("$DateEnd", "local")

    $LatencyItems=[System.Collections.ArrayList]@()
    $mailbox = (Get-MoveRequestProperties $MoveRequest).mailbox

    Write-LogEntry -LogEntryText "Retrieving move request source latency for mailbox $mailbox" -LogName $LogName

        for ($j=0 ; $j -lt $MoveRequest.Report.Entries.message.count ; $j++)
        {

        if (($MoveRequest.Report.Entries[$j].CreationTime).ToLocalTime() -ge $DateStart -and ($MoveRequest.Report.Entries[$j].CreationTime).ToLocalTime() -le $DateEnd)
      
            {
            if ($MoveRequest.Report.Entries[$j].SessionStatistics.SourceLatencyInfo.current -gt 0)
                {
                    $list = New-Object -type PSObject
                    $List | Add-Member -MemberType NoteProperty -Name "Mailbox" -Value $mailbox
                    $List | Add-Member -MemberType NoteProperty -Name "TimeStamp" -Value ($MoveRequest.Report.Entries[$j].CreationTime).ToLocalTime()
                    $list | Add-Member -MemberType NoteProperty -Name "Sourcelatency" -Value $MoveRequest.Report.Entries[$j].SessionStatistics.SourceLatencyInfo.current

                    $list.psobject.Typenames.Insert(0,'MoveRequestSourceLatency')
            
                    [void]$LatencyItems.Add($List)
                }
            }
        }
    return $LatencyItems
    }
}

Function Get-MoveRequestHistory
{
<#
  .SYNOPSIS
  The function Get-MoveRequestHistory allows to retrieve all the source latency that were measured for a mailbox move request.
  The source must be a live result form a "Get-MoveRequestStatistics -Includereport" or from an exported XML of it. 
  Note that the Get-MoveRequestStatistics command may take time. If you have several move request to analyse, it is better to
  use the function Get-MoveRequestReport or Get-MoveRequestReportsFromBatch and then use the XMLs

  .DESCRIPTION
  Get-MoveRequestHistory search the move request report for historical events like move creation, incremantal sync, move request parameter change and fatal failure
  
  Author: Guy Groeneveld guyg@microsoft.com

  .EXAMPLE
  To get the history for a single move request
  
  Get-MoveRequestStatistics user1@contoso.com -IncludeReport | Get-MoveRequestHistory
  
  .EXAMPLE
  To get the history events for for all move requests based on XMLs and export it to a CSV
  
  Dir *.xml | Foreach { Import-CliXML $_ | Get-MoveRequestHistory } | Export-CSV -path .\history.csv -NoTypeInformation -Encoding UTF8

  .EXAMPLE
  If you want to have the full move request message history

  Get-MoveRequestStatistics user1@contoso.com -IncludeReport | Get-MoveRequestHistory -All

  .EXAMPLE
  If you want to retrieve all the content change messages

  Get-MoveRequestStatistics user1@contoso.com -IncludeReport | Get-MoveRequestHistory -all $true | where { $_.message -like "*content change*" }

  .PARAMETER MoveRequest
  The source move request including report.

  .PARAMETER All
  Will retrieve complete move request messages
  
  .PARAMETER LogName
  The name of a text file to write the mailbox name being scanned. This will appear also with the Verbose mode
  #> 
    [cmdletbinding()]
    Param (
        [parameter(ValueFromPipeline=$True)]
        $MoveRequest,
        [string]$LogName=$null,
        [switch]$All
        )
    Process
    { 

        
    $HistoryItems=[System.Collections.ArrayList]@()
    $mailbox = (Get-MoveRequestProperties $MoveRequest).mailbox

    Write-LogEntry -LogEntryText "Retrieving move request history for mailbox $mailbox" -LogName $LogName
    
    #Retrieveing move request modification parameters
    for ($i=0 ; $i -lt $MoveRequest.Report.DebugEntries.count ; $i++)
        {
              
            if ($MoveRequest.Report.DebugEntries[$i].debugdata -like "Set-MoveRequest*")
                {
                    $ErrorActionPreference="Stop"
                    try
                    {
                        [string]$mvreq = $MoveRequest.Report.DebugEntries[$i].DebugData
                        if ($mvreq.length -gt 32)
                        {
                            [string]$action = $mvreq.Replace("`n", " ")
                        }
                        else
                        {
                            [string]$action = "Changed: No parameters available"
                        }

                        $list = New-Object -type PSObject
                        $List | Add-Member -MemberType NoteProperty -Name "Mailbox" -Value $mailbox
                        $List | Add-Member -MemberType NoteProperty -Name "TimeStamp" -Value ($MoveRequest.Report.DebugEntries[$i].CreationTime).ToLocalTime()
                        $list | Add-Member -MemberType NoteProperty -Name "Message" -Value $action
                        [void]$HistoryItems.Add($list)
                    }
                    catch
                    {
                        Write-LogEntry -LogEntryText "Error in Debug entry $i for mailbox $mailbox"
                        Write-LogEntry -LogEntryText $_.exception 
                    }
                }
            }

    [datetime]$SWRCTime = 0    
    #retrieving command history

    if ($MoveRequest.StartTimestamp)
    {
        $list = New-Object -type PSObject
        $List | Add-Member -MemberType NoteProperty -Name "Mailbox" -Value $mailbox
        $List | Add-Member -MemberType NoteProperty -Name "TimeStamp" -Value ($MoveRequest.StartTimestamp).ToLocalTime()
        $list | Add-Member -MemberType NoteProperty -Name "Message" -Value "Move Request processing Started"
        [void]$HistoryItems.Add($list)
    }

    
    if ($MoveRequest.FinalSyncTimestamp)
    {
        $list = New-Object -type PSObject
        $List | Add-Member -MemberType NoteProperty -Name "Mailbox" -Value $mailbox
        $List | Add-Member -MemberType NoteProperty -Name "TimeStamp" -Value ($MoveRequest.FinalSyncTimestamp).ToLocalTime()
        $list | Add-Member -MemberType NoteProperty -Name "Message" -Value "Final Sync start"
        [void]$HistoryItems.Add($list)
    }
                
    if ($MoveRequest.CompletionTimestamp)
    {
        $list = New-Object -type PSObject
        $List | Add-Member -MemberType NoteProperty -Name "Mailbox" -Value $mailbox
        $List | Add-Member -MemberType NoteProperty -Name "TimeStamp" -Value ($MoveRequest.CompletionTimestamp).ToLocalTime()
        $list | Add-Member -MemberType NoteProperty -Name "Message" -Value "Move request Completed"
        [void]$HistoryItems.Add($list)
    }
                
    if ($MoveRequest.SuspendedTimestamp)
    {
        $list = New-Object -type PSObject
        $List | Add-Member -MemberType NoteProperty -Name "Mailbox" -Value $mailbox
        $List | Add-Member -MemberType NoteProperty -Name "TimeStamp" -Value ($MoveRequest.SuspendedTimestamp).ToLocalTime()
        $list | Add-Member -MemberType NoteProperty -Name "Message" -Value "Move Request Suspended"
        [void]$HistoryItems.Add($list)
    }

    if ($MoveRequest.FailureTimestamp)
    {
        $list = New-Object -type PSObject
        $List | Add-Member -MemberType NoteProperty -Name "Mailbox" -Value $mailbox
        $List | Add-Member -MemberType NoteProperty -Name "TimeStamp" -Value ($MoveRequest.FailureTimestamp).ToLocalTime()
        $list | Add-Member -MemberType NoteProperty -Name "Message" -Value "Last Failure for this request"
        [void]$HistoryItems.Add($list)
    }

    for ($j=0 ; $j -lt $MoveRequest.Report.Entries.message.count; $j++)
        {
            if ($All)
            {
                $list = New-Object -type PSObject
                $List | Add-Member -MemberType NoteProperty -Name "Mailbox" -Value $mailbox
                $List | Add-Member -MemberType NoteProperty -Name "TimeStamp" -Value ($MoveRequest.Report.Entries[$j].CreationTime).ToLocalTime()
                $list | Add-Member -MemberType NoteProperty -Name "Message" -Value $MoveRequest.Report.Entries[$j].message.tostring() 
                [void]$HistoryItems.Add($list)
            }
        Else
        {
                

                                
                if ( $MoveRequest.Report.Entries[$j].message.tostring() -like "*move request*" )
                {
                    #retrieving first the action message
                    [string]$action = $MoveRequest.Report.Entries[$j].message.tostring()
                    $Startstring = $action.indexof( "/",$action.indexof("/", $action.IndexOf("/") +1) +1 )+1
                    $Stringlength = $action.length - $Startstring
                    $action = $action.Substring($Startstring,$Stringlength)
                    $action = $action.Replace("'' ","")
                    $action = $action.Replace("'","")
                    
                    #We retrieve already the move request modification from the debug entries with the changed parameters
                    #So we don't need to get it here again
                    
                        $list = New-Object -type PSObject
                        $List | Add-Member -MemberType NoteProperty -Name "Mailbox" -Value $mailbox
                        $List | Add-Member -MemberType NoteProperty -Name "TimeStamp" -Value ($MoveRequest.Report.Entries[$j].CreationTime).ToLocalTime()
                        $list | Add-Member -MemberType NoteProperty -Name "Message" -Value $action
                        [void]$HistoryItems.Add($list)
                    
                    
                }

                if ($MoveRequest.Report.Entries[$j].message.tostring() -like "*Fatal error*")
                {
                    $list = New-Object -type PSObject
                    $List | Add-Member -MemberType NoteProperty -Name "Mailbox" -Value $mailbox
                    $List | Add-Member -MemberType NoteProperty -Name "TimeStamp" -Value ($MoveRequest.Report.Entries[$j].CreationTime).ToLocalTime()
                    $list | Add-Member -MemberType NoteProperty -Name "Message" -Value $MoveRequest.Report.Entries[$j].message.tostring()
                    [void]$HistoryItems.Add($list)
                }
                
                if ($MoveRequest.Report.Entries[$j].message.tostring() -like "Initial seeding completed*")
                {
                    $list = New-Object -type PSObject
                    $List | Add-Member -MemberType NoteProperty -Name "Mailbox" -Value $mailbox
                    $List | Add-Member -MemberType NoteProperty -Name "TimeStamp" -Value ($MoveRequest.Report.Entries[$j].CreationTime).ToLocalTime()
                    $list | Add-Member -MemberType NoteProperty -Name "Message" -Value $MoveRequest.Report.Entries[$j].message.tostring()
                    [void]$HistoryItems.Add($list)
                    [datetime]$SWRCTime = $MoveRequest.Report.Entries[$j].CreationTime
                }
                if ($MoveRequest.Report.Entries[$j].message.tostring() -like "*Stage: IncrementalSync. Percent complete: 95.*" -and $MoveRequest.Report.Entries[$j].CreationTime -gt $SWRCTime.AddHours(1))
                {
                    $list = New-Object -type PSObject
                    $List | Add-Member -MemberType NoteProperty -Name "Mailbox" -Value $mailbox
                    $List | Add-Member -MemberType NoteProperty -Name "TimeStamp" -Value ($MoveRequest.Report.Entries[$j].CreationTime).ToLocalTime()
                    $list | Add-Member -MemberType NoteProperty -Name "Message" -Value "IncrementalSync. Percent complete: 95%"
                    [void]$HistoryItems.Add($list)
                }
                
            }
        }
    [System.Collections.ArrayList]$HistoryItems = $HistoryItems | Sort-Object -Property { $_.TimeStamp -as [datetime] }
    return $HistoryItems
    
    }

}


Function Get-MoveRequestThroughputFromReport
{
<#
  .SYNOPSIS
  The function Get-MoveRequestThroughputFromReport attempt to retrieve the throughput from the move request report.
  The source must be a live result form a "Get-MoveRequestStatistics -Includereport" or from an exported XML of it. 
  Note that the Get-MoveRequestStatistics command may take time. If you have several move request to analyse, it is better to
  use the function Get-MoveRequestReport or Get-MoveRequestReportsFromBatch and then use the XMLs

  .DESCRIPTION
  Get-MoveRequestThroughputFromReport attempt to retrieve the move request throughput from the report. The entries in the report
  are no showing up the bytes transfered but rather the replicated data from the mailbox. We analyze the report message and extract the data
  The report messages are looking like this one:

  Copy progress: 1388/1598 messages, 546.1 MB (572,582,873 bytes)/621.9 MB (652,138,174 bytes), 68/79 folders completed.
  On this entry we have replicated 546.1 MB from a source mailbox size of 621.9 MB
  By keeping this value and getting the next one and comparing the replicated size and the minutes between the two report entries
  we determine the amount of data sent per minutes.

  If you compare the TotalMailBoxSize with BytesTransferred you will see that we transfer more bytes than the data. We don't have the
  values per message. Thus we get the percentage difference between TotalMailBoxSize and BytesTransferred. We then apply this percentage increase
  to all the measured values. Deltasize is the data related to mailbox size and Deltabytes is the adjusted one
    Here is an example output:

    StartTime            : 9/23/2017 12:05:34 AM
    EndTime              : 9/23/2017 12:20:20 AM
    Mailbox              : user20
    MigrationBatch       : FTC-Btach
    Already migrated     : 64,563,756
    Current Mailbox Size : 94,789,523
    deltasize            : 64,563,756
    deltabytes           : 73,675,389
    Percent Migrated     : 64.71%
    MegaBytesPerMinute   : 5
    BytesPerMinute       : 4,989,716
    MinutesSpent         : 15
    Message              : Copy progress: 1282/2021 messages, 61.57 MB (64,563,756 bytes)/90.4 MB (94,789,523 bytes), 17/31 folders completed.

  -----------------------------------------------------------------------------------------------------------------------------------------  
  THE RESULT IS AN INDICATION. THE ONLY WAY TO HAVE REAL THROUGHPUT VALUES IS BY LOOKING AT THE LIVE THROUGHPUT OF A MAILBOX BEING MOVED
  -----------------------------------------------------------------------------------------------------------------------------------------
  
  My tests showed an average of more or less 20% difference between live and report.

  For live throughput you can look at the BytesTransferredPerMinute property of a move request currently moved as this attribute gets only documented
  when the mailbox is actively moved. You can also use the function from this module Get-MoveRequestLiveThroughputPerBatch.
  
  Author: Guy Groeneveld guyg@microsoft.com

  .EXAMPLE
  To get the throughput for a single move request
  
  Get-MoveRequestStatistics user1@contoso.com -IncludeReport | Get-MoveRequestThroughputFromReport
  
  .EXAMPLE
  To get all the throughput for for all move requests based on XMLs and export it to a CSV
  
  Dir *.xml | Foreach { Import-CliXML $_ | Get-MoveRequestThroughputFromReport } | Export-CSV -path .\throughput.csv -NoTypeInformation -Encoding UTF8

  .PARAMETER MoveRequest
  The source move request including report.

  .PARAMETER LogName
  The name of a text file to write the mailbox name being scanned. This will appear also with the Verbose mode
  #> 


[CmdletBinding()]

Param(
      [parameter(ValueFromPipeline=$True)]$MoveRequest,
      [string]$LogName=$null
     )
Process
    {
        #initializing some variables to be used later
        $Messages = [System.Collections.ArrayList]@()
        [double]$movespeed = 0
        [double]$previousreplicatedsize = 0
        [double]$megabytesperminute = 0
        [datetime]$previousdatetime = 0
        [datetime]$previousdatetime = 0
        [double]$MinutesSpent = 0
        [double]$deltabytes = 0
        [double]$deltasize = 0
        [double]$MailboxSize = 0
        
        
        
        #We need to check if report is included
        if (!$MoveRequest.report) 
        {
            #exiting the loop for this mailbox
            Write-LogEntry -LogName $LogName -LogEntryText "The move request does not include the report"
            break
        }

        #Depending if the xml are coming from move request statistics or from migrtation user
        #the mailbox is not referenced the same way

        $mailbox = (Get-MoveRequestProperties $MoveRequest).mailbox
        Write-LogEntry -LogEntryText "Retrieving move request throughput for mailbox $mailbox" -LogName $LogName
        
        #We initiate the copy count
        [int]$CopyCount = 0
        
        #As we have only the data for mailbox size related bytes and not the real bytes transfered
        #We determine the ratio between TotalMailboxSize + TotalArchiveSize compared to bytes transfered
        [double]$BytesTransferred = $MoveRequest.BytesTransferred | Get-BytesFromExString
        [double]$TotalMailboxSize = $MoveRequest.TotalMailboxSize | Get-BytesFromExString
        if ($MoveRequest.TotalArchiveSize)
        {
            $TotalMailboxSize = $TotalMailboxSize + ($MoveRequest.TotalArchiveSize | Get-BytesFromExString)
        }

        #So the ratio is
        $Ratio = ($BytesTransferred - $TotalMailboxSize) * 100 / $TotalMailboxSize
        Write-LogEntry -LogEntryText "The ratio between mailbox size and bytes transfrred is $ratio" -LogName $LogName

        #Retrieving all the report messages and get the one relatives to amount replicated
        #If the option IncludeReport was selectionned when getting move request statistics
        #The messages are held in report.entries.messages
        for ( $entries = 0 ; $entries -lt $MoveRequest.report.entries.count ; $entries++ )
        {
            $list = New-Object -type PSObject
        
            if ($MoveRequest.report.entries[$entries].Message.ToString() -like "*CreatingFolderHierarchy*")
            {
                #When we create folders in the target, we start migrating            
                $previousdatetime = $MoveRequest.report.entries[$entries].creationtime
                #Storing start time so we can get the total time it took to migrate the user
                [datetime]$starttime = $previousdatetime
            }
        
            if ($MoveRequest.report.entries[$entries].Message.ToString() -like "Copy progress:*") 
            {
                #We need to know how much time we have found "Copy progress:*"
                #As we may have none if the mailbox is really small or the network is very good
                #In that case we will use the completion status to determine the speed
                $CopyCount++

                $list | Add-Member -MemberType NoteProperty -Name "StartTime" -Value ($previousdatetime).ToLocalTime()
                $list | Add-Member -MemberType NoteProperty -Name "EndTime" -Value ($MoveRequest.report.entries[$entries].creationtime).ToLocalTime()
                $list | Add-Member -MemberType NoteProperty -Name "Mailbox" -Value $mailbox
                #Adding batchname
                $List | Add-Member -MemberType NoteProperty -Name "MigrationBatch" -Value $batch
                
                [string]$FullMessage = $MoveRequest.report.entries[$entries].Message.ToString()
                #Retrieveing the values of replicated size compared to mailbox size from the message log
                # message looking like this one
                #Copy progress: 24673/125459 messages, 603.9 MB (633,226,153 bytes)/4.422 GB (4,748,355,827 bytes), 87/1076 folders completed.
                #So we parse the string up to the first () pair, get the value and then the second () pair and get the value
                #The mailbox size is related to SWRC, mailbox size here is 95% and not 100%

                $ReplicatedSize = $FullMessage | Get-BytesFromExString

                # Now it is time to save the value
                $list | Add-Member -MemberType NoteProperty -Name "Already migrated" -Value ("{0:N0}" -f ($ReplicatedSize))
                
                #Retrieveing the second "(" to get the mailbox size in bytes
                #Quite ugly for the moment, will have to come back on this later when I'll have time
                $Secondleftbracket = $FullMessage.IndexOf("(",$FullMessage.IndexOf(")") + 2 ) + 1
                $Secondrightbracket = $FullMessage.IndexOf(")",$Secondleftbracket) - 6
                $Secondstringlength = $Secondrightbracket - $Secondleftbracket
                $mailboxsize = $FullMessage.Substring($Secondleftbracket,$Secondstringlength)

                $mailboxsize = $mailboxsize -replace "[^0-9]"

                $list | Add-Member -MemberType NoteProperty -Name "CurrentMailboxSizeMB" -Value ("{0:N0}" -f ($mailboxsize / 1MB))

                if (($ReplicatedSize - $previousreplicatedsize) -ge 0) 
                    {
                        $deltasize = $ReplicatedSize - $previousreplicatedsize
                    }  
                    Else
                    {
                        $deltasize = 0
                    }
                #Making a guess on real bytes sent based on nthe ratio
                $deltabytes  = $deltasize * ( 1 + $Ratio / 100)             

                $list | Add-Member -MemberType NoteProperty -Name "deltasize" -Value ("{0:N0}" -f ($deltasize))
                $list | Add-Member -MemberType NoteProperty -Name "deltabytes" -Value ("{0:N0}" -f ($deltabytes))

                #Percent Migrated
                If ($mailboxsize -ne 0 )
                    {
                        #The size we get is the size for cutover, thus 95% size
                        #So we adjust the size
                        $mailboxsize = [double]$mailboxsize * 100 / 95
                        $pctmig = "{0:P2}" -f ([double]$ReplicatedSize / [double]$mailboxsize)
                        $list | Add-Member -MemberType NoteProperty -Name "PercentMigrated" -Value $pctmig
                    }
                    else 
                    {
                        $list | Add-Member -MemberType NoteProperty -Name "PercentMigrated" -Value "0%"
                    }

                #Determining migration speed
                #We look at the timestamp and the amount of data sent per minutes
                #To do that we need to keep the current replication size to be able to compare it to the next one
                #We can have zero values

                
                if ( $ReplicatedSize -gt 0 )
                {
                    
                    $speedtime = $MoveRequest.report.entries[$entries].creationtime - $previousdatetime

                    $bytesperminutes = $deltabytes / $speedtime.TotalMinutes
                    #We can have negative values if the replicated size has shrinked
                    #Found one occurence
                    if ($bytesperminutes -lt 0)
                    {
                        $bytesperminutes = 0
                    }
                    $megabytesperminute = $bytesperminutes / 1MB

                    #We compute the time spent on this request so far
                    $MinutesSpent = $MinutesSpent + ($MoveRequest.report.entries[$entries].creationtime - $previousdatetime).totalminutes
                    
                    #The replicated size value has changed and needs to be updated
                    #We won't update it if there's been no change
                    $previousreplicatedsize = $ReplicatedSize
                
                    
                    #We can have a negative value as mailbox size can shrink during database maintenance
                    #In that case we assume the speed to be 0
                    if ($megabytesperminute -lt 0)
                    {
                        $megabytesperminute = 0
                        Write-LogEntry -LogName $LogName -LogEntryText ("$Mailbox : Database maintenance has decreased mailbox size reducing speed to zero for entry time :" + $MoveRequest.report.entries[$entries].creationtime ) 
                    }

                }

                Else
                {
                    $bytesperminutes = 0                    
                    $megabytesperminute = 0
                    $deltasize = 0
                    Write-LogEntry -LogName $LogName -LogEntryText ("$Mailbox : Database maintenance has decreased mailbox size reducing speed to zero for entry time :" + $MoveRequest.report.entries[$entries].creationtime ) 
                }

                #We store the replicatedsize and speedtime to compare it later in next loop and determine the speed
                
                $previousdatetime = $MoveRequest.report.entries[$entries].creationtime


                $List | Add-Member -MemberType NoteProperty -Name "MegaBytesPerMinute" -Value ("{0:N2}" -f ($megabytesperminute))
                $List | Add-Member -MemberType NoteProperty -Name "BytesPerMinute" -Value ("{0:N0}" -f ($bytesperminutes))
                $list | Add-Member -MemberType NoteProperty -Name "MinutesSpent" -Value ("{0:N0}" -f ($MinutesSpent))

                

                #We store the full message too, can be useful in case of doubts on the extracted results
                $List | Add-Member -MemberType NoteProperty -Name "Message" -Value $MoveRequest.report.entries[$entries].Message.ToString()

                $List.psobject.Typenames.Insert(0,'MoveRequestThroughputFromReport')

                [void]$Messages.Add($list)
            }
        
            <#It may happen that the mailbox is so small that we don't have entries in the report regarding what is replicated
            Or we have now the Cutover Initiated and need to determine cutover mailboxsize and creation time
            The finalization starts just few seconds before the mailbox verification is done so we start from there as we have
            The mailbox size up there too
            Here is an example of what the message looks like:
            Mailbox contents verification complete: 103 folders, 6559 items, 1016 MB (1,065,774,745 bytes).#>

            if ($MoveRequest.report.entries[$entries].Message.ToString() -like "Mailbox contents verification complete:*")
            {
                
                $CutoverMailboxSize = $MoveRequest.report.entries[$entries].Message.ToString()
                            
                $ReplicatedSize = $CutoverMailboxSize | Get-BytesFromExString
                
                #We are at 95% of the final mailbox size, so we need to get the 95% of the value
                #$replicatedsize = "{0:N0}" -f ([double]$ReplicatedSize * 0.95)

                #We store the replicatedsize and speedtime to compare it later in next loop and determine the speed
                $previousreplicatedsize = $ReplicatedSize
                $previousdatetime = $MoveRequest.report.entries[$entries].creationtime
            }


            if ($MoveRequest.report.entries[$entries].Message.ToString() -like "Move has completed and final cleanup has started.")
            {
                        
                    $ReplicatedSize = $MoveRequest.report.sourcemailboxsize.itemsize
                    
                    $speedtime = $MoveRequest.report.entries[$entries].creationtime - $previousdatetime
                    $deltasize = $ReplicatedSize - $previousreplicatedsize

                    $deltabytes  = $deltasize * ( 1 + $Ratio / 100)  

                    If ($deltabytes -lt 0)
                    {
                        $deltabytes = 0
                    }
                    #It may happen that $speedtime is lower than one minute.
                    #In that case dividing result in a multiplier and gives huge erroneous results
                    #Speed cannot be computed here

                    if ($speedtime.totalminutes -lt 1)
                    {
                        $bytesperminutes = ($deltabytes / $speedtime.totalseconds) * 60
                        Write-LogEntry -LogName $LogName -LogEntryText ("$Mailbox : Time is less than one minute, rounded to one :" + $MoveRequest.report.entries[$entries].creationtime ) 
                    }
                    Else
                    {
                        $bytesperminutes = $deltabytes / $speedtime.totalminutes
                    }

                    $megabytesperminute = "{0:N2}" -f ($bytesperminutes /1MB ) 

                    #We can have a negative value as mailbox size can shrink during database maintenance
                    #In that case we assume the speed to be 0
                    if ($megabytesperminute -lt 0)
                    {
                        $megabytesperminute = 0
                        Write-LogEntry -LogName $LogName -LogEntryText ("$Mailbox : Database maintenance has decreased mailbox size reducing speed to zero for entry time :" + $MoveRequest.report.entries[$entries].creationtime ) 
                    }

                    #We compute the time spent on this request so far
                    $MinutesSpent = $MinutesSpent + ($MoveRequest.report.entries[$entries].creationtime - $previousdatetime).totalminutes
                    
                    #How much did we repolicate during the last period of time
                    if (($ReplicatedSize - $previousreplicatedsize) -ge 0) 
                    {
                        $deltasize = $ReplicatedSize - $previousreplicatedsize
                    }  
                    Else
                    {
                        $deltasize = 0
                    }                
                    
                    $deltabytes  = $deltasize * ( 1 + $Ratio / 100) 

                    #We need to populate $list as we are in another condition loop
                    $list | Add-Member -MemberType NoteProperty -Name "StartTime" -Value $previousdatetime
                    $list | Add-Member -MemberType NoteProperty -Name "EndTime" -Value ($MoveRequest.report.entries[$entries].creationtime).ToLocalTime()
                    $list | Add-Member -MemberType NoteProperty -Name "Mailbox" -Value $mailbox
                    $List | Add-Member -MemberType NoteProperty -Name "MigrationBatch" -Value $batch
                    $list | Add-Member -MemberType NoteProperty -Name "Already migrated" -Value ("{0:N0}" -f ($ReplicatedSize))
                    $list | Add-Member -MemberType NoteProperty -Name "CurrentMailboxSizeMB" -Value ("{0:N0}" -f ($ReplicatedSize / 1MB))
                    $list | Add-Member -MemberType NoteProperty -Name "deltasize" -Value ("{0:N0}" -f ($deltasize))
                    $list | Add-Member -MemberType NoteProperty -Name "deltabytes" -Value ("{0:N0}" -f ($deltabytes))
                    $list | Add-Member -MemberType NoteProperty -Name "PercentMigrated" -Value "100%"
                    $List | Add-Member -MemberType NoteProperty -Name "MegaBytesPerMinute" -Value $megabytesperminute
                    $List | Add-Member -MemberType NoteProperty -Name "BytesPerMinute" -Value $bytesperminutes
                    $list | Add-Member -MemberType NoteProperty -Name "MinutesSpent" -Value ("{0:N0}" -f ($MinutesSpent))

            

                    #We store the full message too, can be useful in case of doubts on the extracted results
                    $List | Add-Member -MemberType NoteProperty -Name "Message" -Value $MoveRequest.report.entries[$entries].Message.ToString()

                    $List.psobject.Typenames.Insert(0,'MoveRequestThroughputFromReport')

                    [void]$Messages.Add($list)
                

            }
            
            #If any of the previous check were False, we need to start the counter the next time we connect to the source mailbox
            #For that purpose we set the previous date time to get throughput only when we are effectively connected
            if ($MoveRequest.report.entries[$entries].Message.ToString() -like "Connected to source mailbox*") 
            {
                $previousdatetime = $MoveRequest.report.entries[$entries].creationtime
            }
        }

        Write-LogEntry -LogName $LogName -LogEntryText "Processed $CopyCount entries containing copy progress"
        Write-LogEntry -LogName $LogName -LogEntryText "Finished Mailbox  : $mailbox"
        

       Return $Messages
    

    }

}

Function Get-MoveRequestReport
{
<#
  .SYNOPSIS
  The function Get-MoveRequestReport allows to export to XML the move request statistics in order to be able to analyze the move request
  without having to be connected to Exchange Online.

  .DESCRIPTION
  Get-MoveRequestReport will get the move request staistics including the report and export it to an XML file per move request. 
  We can automatically compress the result. This is usefull if you plan to move the data to another server or if you need to send the data to support.
  Be carefull about your disk space if you don't compress as the xml can become pretty big sometimes.
  
  Author: Guy Groeneveld guyg@microsoft.com

  .EXAMPLE
  To save the request statistics for a single user
  Get-MoveRequestReport user58

  .EXAMPLE
  To save all the move request statistics corresponding to PrimarySMTPAddress in a CSV file and save the resulting files to c:\temp
  Import-CSV csvfile.csv | foreach { Get-MoveRequestReport $_.PrimarySMTPAddress -DestinationPath "c:\temp" }

  .EXAMPLE
  To save and compress the request statistics for a single user
  Get-MoveRequestReport user58 -Compress

  .PARAMETER User
  The user to save the move request statistics.

  .PARAMETER Compress
  Will compress the XML file
  
  .PARAMETER LogName
  The name of a text file to write the mailbox name being scanned. This will appear also with the Verbose mode
  #> 


[CmdletBinding()]

Param(
      [parameter(ValueFromPipeline=$True)]$User=$null,
      [string]$DestinationPath = (Get-Location).Path,
      [switch]$Compress,
      [string]$LogName=$null
      )

    process
    {
        if (Test-Path -Path $DestinationPath)
        {
            if ($User)
            {
                #We can call this function from Get-MoveRequestReportsFromBatch
                #If verbose was specified we must pass verbose here
                if (-not $PSBoundParameters.ContainsKey('Verbose'))
                {
                    $VerbosePreference = $PSCmdlet.GetVariableValue('VerbosePreference')
                }
                
                
                #We need to check if the move request exists 

                Write-LogEntry -LogEntryText "Retrieving move request XML report for user mailbox $user" -LogName $LogName

                $request = Get-MoveRequestStatistics -Identity $User -IncludeReport -Diagnostic -DiagnosticArgument verbose

                $mailbox = (Get-MoveRequestProperties $Request).mailbox

                $id = $request.displayname -replace "[^A-Za-z0-9_]"
                
                #we make sure the path ends with a \, if not we add one
                if (!$DestinationPath.EndsWith("\"))
                {
                    $DestinationPath = $DestinationPath + "\"
                }

                $xmlpath = $DestinationPath + $id + ".xml"
                $zippath = $DestinationPath + $id + ".zip"
                #We make the xml export
                Export-Clixml -Path $xmlpath -InputObject $request
                    
                if ($Compress)
                {
                    #wecompress the xml and delete the xml
                    Compress-Archive -Path $xmlpath -DestinationPath $zippath -Force -CompressionLevel Optimal
                    Remove-Item -path $xmlpath
                }
               
            }
        }
        Else
        {
            Write-LogEntry -LogName $LogName -LogEntryText "The destination path $destinationpath is invalid"
            #Throwing the error to the console
            Get-ChildItem -path $DestinationPath
        }
    }
}

Function Get-MoveRequestReportsFromBatch
{
<#
  .SYNOPSIS
  The function Get-MoveRequestReportsFromBatch allows to export to XML the move request statistics of all the mailboxes migrated through a batch

  .DESCRIPTION
  Get-MoveRequestReportsFromBatch will get the move request statistics including the report and export it to XML files. 
  We can automatically compress the result. This is usefull if you plan to move the data to another server or if you need to send the data to support.
  Be carefull about your disk space if you don't compress as the xml can become pretty big sometimes.
  
  Author: Guy Groeneveld guyg@microsoft.com

  .EXAMPLE
  To save the request statistics for a batch and save it in the current directory
  Get-MoveRequestReportsFromBatch -MigrationBatch "FTC-Batch" 

  .PARAMETER MigrationBatch
  The Migration Batch to save the move request statistics from.

  .PARAMETER Compress
  Will compress the XML files
  
  .PARAMETER LogName
  The name of a text file to write the mailbox name being scanned. This will appear also with the Verbose mode
  #> 

    [CmdletBinding()]

Param(
      [parameter(ValueFromPipeline=$True)]$MigrationBatch=$null,
      [string]$DestinationPath = (Get-Location).Path,
      [switch]$Compress,
      [string]$LogName=$null
      )

    process
    {
       $batchname = "MigrationService:" + $MigrationBatch
       #Now we can save the xml export
       $MoveRequest = Get-MoveRequest -BatchName $batchname

       For ( $i=0 ; $i -lt $MoveRequest.count ; $i++)
       {
            $currentmove = $MoveRequest[$i].name

            Get-MoveRequestReport -user $currentmove -DestinationPath $DestinationPath -Compress $Compress 

       }
    }
}

Function Get-MoveRequestLiveThroughputPerBatch 
{

<#
  .SYNOPSIS
  The function Get-MoveRequestLiveThroughputPerBatch will get the BytesTransferredPerMinute for all the mailboxes migrated through a batch with an "InProgress" state.

  .DESCRIPTION
  Get-MoveRequestLiveThroughputPerBatch get all the move request statistics for mailbox in the "InProgress" state and sum the BytesTransferredPerMinute.We then save the data per mailboxes
  plus the summarized data. In the chosen destination path we append the data everytime the function run if there are mailboxes currently transfering bytes.

  CurrentPerMailboxBytesTransfered.csv will contain data per mailbox.
  CurrentTotalBytesTransfered.csv will contain summarized data and the effective amount of mailbox currently getting data

  The function returns the amount of mailboxes being at the "Inprogress" state. You can use this to determine if you will run the command again
  For example you set a "Do While" powershell loop with a sleep of 5 minutes to get the status every five minutes. When the function returns 0 you are done.
  You can also use the scheduler, but this gets more complicated as you will need Office 365 creds to open the session.
  
  Author: Guy Groeneveld guyg@microsoft.com

  .EXAMPLE
  To save the request statistics for a batch and save it in the current directory
  Get-MoveRequestLiveThroughputPerBatch -BatchName "FTC-Batch" 

  .PARAMETER BatchName
  The Migration Batch to save the move request statistics from.

  .PARAMETER Progress
  Specify this one if you want to see a progress bar.

  .PARAMETER LogName
  The name of a text file to write the mailbox name being scanned. This will appear also with the Verbose mode
  #> 
    [cmdletbinding()]
    Param (
        [parameter(ValueFromPipeline=$True)]
        [string]$BatchName = $Null,
        [string]$DestinationPath = (Get-Location).Path,
        [string]$LogName=$Null,
        [switch]$Progress
        )

    Process
    {
        $BytesTransfered = [System.Collections.ArrayList]@()
        $MoveRequests = $null 
        $stats = $null 
        [int]$MoverequestProcessedCount=0

        if (Test-Path -Path $DestinationPath)
        {
            
            #we make sure the path ends with a \, if not we add one
            if (!$DestinationPath.EndsWith("\"))
            {
                $DestinationPath = $DestinationPath + "\"
            }
      
            If (!$BatchName.StartsWith("MigrationService:"))
            {
                $BatchName = "MigrationService:" + $BatchName
            }
        
            $MoveRequests = Get-MoveRequest -batchname $BatchName -MoveStatus inprogress

            If ($MoveRequests.count -gt 0)
            {

                For ( $i=0 ; $i -lt $MoveRequests.count ; $i++)
                {
                
                    $stats = Get-MoveRequestStatistics $Moverequests[$i].identity | Where-Object { $_.BytesTransferredPerMinute -notlike "*0 B (0 bytes)*" }

                    $mailbox = (Get-MoveRequestProperties $stats).mailbox
                    
                    $Bytes = New-Object -type PSObject 
                    $CurrentBytes = New-Object -type PSObject 
                    
                            
                    if ($stats)
                    {
                        Write-LogEntry -LogEntryText "Retrieving move request LiveThroughput for mailbox $mailbox" -LogName $LogName

                        #Retreiving current bytes transfer and remove chars
                        $BytesTransferredPerMinute = $stats.BytesTransferredPerMinute.tostring() | Get-BytesFromExString

                        #Retreiving total sent bytes for mailbox and remove chars
                        $BytesTransferred = $stats.BytesTransferred.tostring() | Get-BytesFromExString
                        
                        $mailbox = $stats.MailboxIdentity.Name
                
                        
                        $Bytes | Add-Member -MemberType NoteProperty -Name "TimeStamp" -Value (get-date -Format G)
                        $Bytes | Add-Member -MemberType NoteProperty -Name "Mailbox" -Value $mailbox
                        $Bytes | Add-Member -MemberType NoteProperty -Name "MegaBytesTransferredPerMinute" -Value ( "{0:N2}" -f ($BytesTransferredPerMinute / 1MB))
                        $Bytes | Add-Member -MemberType NoteProperty -Name "UnformattedBytesPerMinute" -Value $stats.BytesTransferredPerMinute.tostring()
                        $Bytes | Add-Member -MemberType NoteProperty -Name "Status" -Value $stats.status
                        $Bytes | Add-Member -MemberType NoteProperty -Name "StatusDetail" -Value $stats.StatusDetail
                        $Bytes | Add-Member -MemberType NoteProperty -Name "MegaBytesTransferred" -Value ( "{0:N2}" -f ($BytesTransferred / 1MB ))
                        $Bytes | Add-Member -MemberType NoteProperty -Name "PercentComplete" -Value $stats.PercentComplete
                        [void]$BytesTransfered.Add($Bytes)
                        
                        $MoverequestProcessedCount++

                        if ($Progress)
                        {
                            [Int]$Progressbar = ($i / $MoveRequests.count * 100 )
                            Write-Progress -Activity "Analyzed Requests stats for mailbox $mailbox" -Status "Percent done: $Progressbar %" -PercentComplete $Progressbar
                        }
                    }

                    
                }            

                #Save mailbox bytes details to a CSV file
                $BytesTransfered | Export-Csv -Path ($destinationPath + "CurrentPerMailboxBytesTransfered.csv") -NoTypeInformation -Encoding UTF8 -Append
                
                #Now we sum the transfered bytes and save this to a CSV file
                $CurrentTotalBytesTransfered = $BytesTransfered | Measure-Object -Property MegaBytesTransferredPerMinute -Sum

                if ($CurrentTotalBytesTransfered)
                {
                    $MegaBytesTransferredPerMinute = "{0:N2}" -f ($CurrentTotalBytesTransfered.sum)
                    $ConcurentMailboxCount = $CurrentTotalBytesTransfered.count
                }
                Else
                {
                    $MegaBytesTransferredPerMinute =0
                    $ConcurentMailboxCount = 0
                }
                
                $CurrentBytes | Add-Member -MemberType NoteProperty -Name "TimeStamp" -Value (get-date -Format G)
                $CurrentBytes | Add-Member -MemberType NoteProperty -Name "MegaBytesTransferredPerMinute" -Value $MegaBytesTransferredPerMinute
                $CurrentBytes | Add-Member -MemberType NoteProperty -Name "ConcurentMailboxCount" -Value $ConcurentMailboxCount
                $CurrentBytes | Add-Member -MemberType NoteProperty -Name "NumOfMoveInProgress" -value $MoveRequests.count

                Write-LogEntry -LogEntryText "Currently transferring $MegaBytesTransferredPerMinute Megabytes For $ConcurentMailboxCount Mailboxes" -LogName $LogName

                #Save summary detail for the current state
                $CurrentBytes | Export-Csv -Path ($destinationPath + "CurrentTotalBytesTransfered.csv") -NoTypeInformation -Encoding UTF8 -Append
            }
            # We got no move request with bytes in transfer, we write this to the CurrentTotalBytesTransfered file
            Else 
            {
                $CurrentBytes = New-Object -type PSObject
                $CurrentBytes | Add-Member -MemberType NoteProperty -Name "TimeStamp" -Value (get-date -Format G)
                $CurrentBytes | Add-Member -MemberType NoteProperty -Name "MegaBytesTransferredPerMinute" -Value 0
                $CurrentBytes | Add-Member -MemberType NoteProperty -Name "ConcurentMailboxCount" -Value 0
                $CurrentBytes | Add-Member -MemberType NoteProperty -Name "NumOfMoveInProgress" -value 0

                Write-LogEntry -LogEntryText "There was no mailboxes with status InProgress" -LogName $LogName

                $CurrentBytes | Export-Csv -Path ($destinationPath + "CurrentTotalBytesTransfered.csv") -NoTypeInformation -Encoding UTF8 -Append
            }
        }
        # The destination path is bad
        Else 
        {
            #Throwing the error to the console
            Get-ChildItem -path $DestinationPath
        }
     return $MoverequestProcessedCount
   }
}


Function Get-MoveRequestTiming
{

<#
  .SYNOPSIS
  The function Get-MoveRequestTiming will get all the timestamps for the mailbox request statistics.

  .DESCRIPTION
  Get-MoveRequestTiming get all the timestamps. If you want to know when the move was created, when it did start, 
  when it did finish the initial seeding, when is the next incremental sync, when it did complete, you can use this function.
  
  Author: Guy Groeneveld guyg@microsoft.com

  .EXAMPLE
  To get the timings
  Get-MoveRequest user@contoso.com | Get-MoveRequestTiming

  .EXAMPLE
  To determine the next time the mailboxes in synced state will do an incremental sync
  Get-MoveRequest  | Get-MoveRequestStatistics | Get-MoveRequestTiming | select mailbox,nextsync

  .PARAMETER MoveRequest
  The move request to look at
  
  .PARAMETER LogName
  The name of a text file to write the mailbox name being scanned. This will appear also with the Verbose mode
  #> 
    [cmdletbinding()]
    Param (
        [parameter(ValueFromPipeline=$True)]
        $MoveRequest,
        [string]$LogName=$null
        )
    Process
    { 
        $mailbox = $moverequest.MailboxIdentity.Name
        Write-LogEntry -LogEntryText "Retrieving move request Time Stamp for mailbox $mailbox" -LogName $LogName
        
        $NextSyncTimestamp = 0
        if ($MoveRequest.message.tostring() -like "*Next incremental sync is scheduled*")
        {
            #We are in Incremntal Sync mode, we can get the next planned sync
            [string]$nextsync = $MoveRequest.message.tostring()
            $startindex = $nextsync.IndexOf("at ") + 3
            $startlength = $nextsync.length - $startindex -1
            [datetime]$NextSyncTimestamp = $nextsync.Substring($startindex,$startlength)
            $NextSyncTimestamp = [datetime]::SpecifyKind("$NextSyncTimestamp","Utc")
            $NextSyncTimestamp = $NextSyncTimestamp.ToLocalTime()
        }


        [timespan]$durationfromstart = $MoveRequest.InitialSeedingCompletedTimestamp - $MoveRequest.StartTimestamp
        [timespan]$durationfromqueued = $MoveRequest.InitialSeedingCompletedTimestamp - $MoveRequest.QueuedTimestamp
        
        $stamp = New-Object -type PSObject
        $stamp | Add-Member -MemberType NoteProperty -Name "Mailbox" -Value $mailbox
        $stamp | Add-Member -MemberType NoteProperty -Name "Queued" -value $MoveRequest.QueuedTimestamp
        $stamp | Add-Member -MemberType NoteProperty -Name "Started" -value $MoveRequest.StartTimestamp
        $stamp | Add-Member -MemberType NoteProperty -Name "LastUpdate" -value $MoveRequest.LastUpdateTimestamp
        $stamp | Add-Member -MemberType NoteProperty -Name "LastSuccessfulSync" -value $MoveRequest.LastSuccessfulSyncTimestamp

        If (-not $NextSyncTimestamp -or $NextSyncTimestamp -eq 0)
        {
            $stamp | Add-Member -MemberType NoteProperty -Name "NextSync" -Value $null
        }
        Else
        {
            $stamp | Add-Member -MemberType NoteProperty -Name "NextSync" -Value $NextSyncTimestamp
        }

        $stamp | Add-Member -MemberType NoteProperty -Name "SeedingCompleted" -value $MoveRequest.InitialSeedingCompletedTimestamp
        $stamp | Add-Member -MemberType NoteProperty -Name "FinalSync" -value $MoveRequest.FinalSyncTimestamp
        $stamp | Add-Member -MemberType NoteProperty -Name "MoveCompleted" -value $MoveRequest.CompletionTimestamp
        $stamp | Add-Member -MemberType NoteProperty -Name "MoveSuspended" -value $MoveRequest.SuspendedTimestamp
        $stamp | Add-Member -MemberType NoteProperty -Name "Failure" -value $MoveRequest.FailureTimestamp
        $stamp | Add-Member -MemberType NoteProperty -name "DurationFromStart" -Value $durationfromstart
        $stamp | Add-Member -MemberType NoteProperty -name "DurationFromQueued" -Value $durationfromqueued
        $stamp.psobject.Typenames.Insert(0,'MoveRequestTiming')
        return $stamp
    }
}


Export-ModuleMember -Function Get-MoveRequestFailures,Get-MoveRequestConnections,Get-MoveRequestThrottlingEvents,Get-MoveRequestSourceLatency,Get-MoveRequestHistory,Get-MoveRequestThroughputFromReport,Get-MoveRequestReport,Get-MoveRequestReportsFromBatch,Get-MoveRequestLiveThroughputPerBatch,Get-MoveRequestTiming -Alias gmvrf,gmvrc,gmvrte,gmvrl,gmvrh,gmvrtr,gmvrr,gmvrrb,gmvltb,gmvrtm